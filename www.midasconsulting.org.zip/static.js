export const host = "https://checklist.midastech.org/";
// export const host = "http://localhost:9000/";
// export const host = "http://192.168.1.105:9000";
